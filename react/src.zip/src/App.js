import { useMemo, useState } from 'react';
import './App.css';
import logoImage from './img/logo.png';
import logoWithStringImage from './img/logo_with_string.png';
import set1Gesture1 from './img/set1_gesture1.png';
import set1Gesture2 from './img/set1_gesture2.png';
import set1Gesture3 from './img/set1_gesture3.png';
import set1Gesture4 from './img/set1_gesture4.png';
import set1Gesture5 from './img/set1_gesture5.png';
import set2Gesture1 from './img/set2_gesture1.png';
import set2Gesture2 from './img/set2_gesture2.png';
import set2Gesture3 from './img/set2_gesture3.png';
import set2Gesture4 from './img/set2_gesture4.png';
import set2Gesture5 from './img/set2_gesture5.png';
import set2Gesture6 from './img/set2_gesture6.png';
import set2Gesture7 from './img/set2_gesture7.png';
import set2Gesture8 from './img/set2_gesture8.png';

const gestureHistory = [
  { id: 1, gesture: '손 흔들기', device: '거실 조명', action: '전원 켜짐', time: '방금 전', confidence: 98 },
  { id: 2, gesture: '오른쪽 스와이프', device: '커튼', action: '열림', time: '3분 전', confidence: 94 },
  { id: 3, gesture: '주먹 쥐기', device: '에어컨', action: '절전 모드', time: '12분 전', confidence: 91 },
  { id: 4, gesture: '위로 올리기', device: '스피커', action: '볼륨 증가', time: '25분 전', confidence: 96 },
  { id: 5, gesture: '손바닥 정지', device: 'TV', action: '일시 정지', time: '41분 전', confidence: 89 },
];

const gestures = [
  { name: '만세 후 왼쪽으로 스윙', imageSrc: set1Gesture1, videoSrc: '' },
  { name: '만세 후 오른쪽으로 스윙', imageSrc: set1Gesture2, videoSrc: '' },
  { name: '만세 후 앞으로 숙이기', imageSrc: set1Gesture3, videoSrc: '' },
  { name: '왼팔을 옆으로 뻗고 날갯짓', imageSrc: set1Gesture4, videoSrc: '' },
  { name: '오른팔을 옆으로 뻗고 날갯짓', imageSrc: set1Gesture5, videoSrc: '' },
  { name: '오른팔로 부채질', imageSrc: set2Gesture1, videoSrc: '' },
  { name: '몸 앞에서 팔 빙글빙글', imageSrc: set2Gesture2, videoSrc: '' },
  { name: '양팔 앞으로 뻗고 위로 스윙', imageSrc: set2Gesture3, videoSrc: '' },
  { name: '양팔 옆으로 뻗고 위로 날갯짓', imageSrc: set2Gesture4, videoSrc: '' },
  { name: '양팔 옆으로 뻗고 아래로 날갯짓', imageSrc: set2Gesture5, videoSrc: '' },
  { name: '왼팔을 들고 팔 돌리기', imageSrc: set2Gesture6, videoSrc: '' },
  { name: '양팔을 내리고 왼쪽으로 스윙', imageSrc: set2Gesture7, videoSrc: '' },
  { name: '양팔을 내리고 오른쪽으로 스윙', imageSrc: set2Gesture8, videoSrc: '' },
];

const gestureSets = [
  {
    id: 'set-1',
    name: '제스처 세트 1',
    description: '기본 홈 제어에 적합한 핵심 제스처입니다.',
    gestureNames: [
      '만세 후 왼쪽으로 스윙',
      '만세 후 오른쪽으로 스윙',
      '만세 후 앞으로 숙이기',
      '왼팔을 옆으로 뻗고 날갯짓',
      '오른팔을 옆으로 뻗고 날갯짓',
    ],
  },
  {
    id: 'set-2',
    name: '제스처 세트 2',
    description: '밝기, 온도, 보안 제어에 어울리는 제스처입니다.',
    gestureNames: [
      '오른팔로 부채질',
      '몸 앞에서 팔 빙글빙글',
      '양팔 앞으로 뻗고 위로 스윙',
      '양팔 옆으로 뻗고 위로 날갯짓',
      '양팔 옆으로 뻗고 아래로 날갯짓',
      '왼팔을 들고 팔 돌리기',
      '양팔을 내리고 왼쪽으로 스윙',
      '양팔을 내리고 오른쪽으로 스윙',
    ],
  },
  {
    id: 'set-3',
    name: '제스처 세트 3',
    description: '아직 등록된 제스처가 없습니다.',
    gestureNames: [],
  },
];

const iotDevices = [
  {
    id: 'light-living',
    name: '조명',
    room: '거실',
    state: '켜짐',
    connection: 'online',
    controls: ['전원 on/off'],
  },
  {
    id: 'tv-living',
    name: 'TV',
    room: '거실',
    state: '켜짐',
    connection: 'online',
    controls: ['전원 on/off', '볼륨 up', '볼륨 down', '채널 up', '채널 down'],
  },
  {
    id: 'ac-bedroom',
    name: '에어컨',
    room: '침실',
    state: '켜짐',
    connection: 'online',
    controls: ['전원 on/off'],
  },
  {
    id: 'doorlock-entrance',
    name: '도어락',
    room: '현관',
    state: '꺼짐',
    connection: 'online',
    controls: ['잠금', '잠금 해제'],
  },
];

const navItems = [
  { id: 'main', label: 'Main', icon: '⌂' },
  { id: 'history', label: '제스처 히스토리', icon: '↺' },
  { id: 'gestures', label: '제스처 목록', icon: '✋' },
  { id: 'devices', label: 'IoT 상태', icon: '◈' },
];

function App() {
  const [activeView, setActiveView] = useState('main');
  const [selectedDeviceId, setSelectedDeviceId] = useState(iotDevices[0].id);
  const [activeGestureSetId, setActiveGestureSetId] = useState(gestureSets[0].id);
  const [selectedGestureSetId, setSelectedGestureSetId] = useState(null);
  const [controlGestures, setControlGestures] = useState({
    'light-living-전원 on/off': '',
    'tv-living-전원 on/off': '',
    'tv-living-볼륨 up': '',
    'tv-living-볼륨 down': '',
    'tv-living-채널 up': '',
    'tv-living-채널 down': '',
    'ac-bedroom-전원 on/off': '',
    'doorlock-entrance-잠금': '',
    'doorlock-entrance-잠금 해제': '',
  });
  const selectedDevice = iotDevices.find((device) => device.id === selectedDeviceId) ?? iotDevices[0];
  const activeGestureSet = gestureSets.find((set) => set.id === activeGestureSetId) ?? gestureSets[0];
  const selectedGestureSet = gestureSets.find((set) => set.id === selectedGestureSetId);
  const visibleGestures = selectedGestureSet
    ? gestures.filter((gesture) => selectedGestureSet.gestureNames.includes(gesture.name))
    : [];
  const activeSetGestureNames = activeGestureSet.gestureNames;
  const assignedGestures = useMemo(
    () => Object.values(controlGestures).filter((gestureName) => activeSetGestureNames.includes(gestureName)),
    [activeSetGestureNames, controlGestures]
  );
  const gestureList = visibleGestures.map((gesture) => ({
    ...gesture,
    status: assignedGestures.includes(gesture.name) ? '활성' : '비활성',
  }));
  const getEffectiveControlGesture = (device, control) => {
    const gestureName = controlGestures[`${device.id}-${control}`];
    return activeSetGestureNames.includes(gestureName) ? gestureName : '';
  };
  const hasActiveControls = (device) => device.controls.some((control) => getEffectiveControlGesture(device, control));
  const getDeviceControlState = (device) =>
    hasActiveControls(device) ? device.connection : 'inactive';
  const selectedDeviceControlState = getDeviceControlState(selectedDevice);
  const connectedDeviceCount = iotDevices.filter(
    (device) => device.connection === 'online' && hasActiveControls(device)
  ).length;

  const updateControlGesture = (control, gestureName) => {
    const targetKey = `${selectedDevice.id}-${control}`;
    const isAlreadyAssigned = Object.entries(controlGestures).some(
      ([key, value]) => key !== targetKey && value === gestureName && activeSetGestureNames.includes(value)
    );

    if (gestureName && isAlreadyAssigned) {
      return;
    }

    setControlGestures((current) => ({
      ...current,
      [targetKey]: gestureName,
    }));
  };

  const deactivateSelectedDevice = () => {
    setControlGestures((current) => {
      const next = { ...current };

      selectedDevice.controls.forEach((control) => {
        next[`${selectedDevice.id}-${control}`] = '';
      });

      return next;
    });
  };

  const deactivateAllControls = () => {
    setControlGestures((current) =>
      Object.keys(current).reduce((next, key) => {
        next[key] = '';
        return next;
      }, {})
    );
  };

  const activateGestureSet = (setId) => {
    setActiveGestureSetId(setId);
    deactivateAllControls();
  };

  return (
    <div className="dashboard">
      <aside className="sidebar">
        <div className="brand">
          <span className="brand-mark">
            <img src={logoImage} alt="WaveHome logo" />
          </span>
          <div>
            <strong>WaveHome</strong>
            <span>Radar Control</span>
          </div>
        </div>

        <nav className="nav-list" aria-label="Dashboard views">
          {navItems.map((item) => (
            <button
              className={`nav-item ${activeView === item.id ? 'active' : ''}`}
              key={item.id}
              onClick={() => setActiveView(item.id)}
              type="button"
            >
              <span aria-hidden="true">{item.icon}</span>
              {item.label}
            </button>
          ))}
        </nav>

      </aside>

      <main className="content">
        {activeView === 'main' && (
          <section className="view">
            <div className="hero">
              <div className="hero-copy">
                <span className="eyebrow">WAVEHOME DASHBOARD</span>
                <h1>파도에 몸을 맡기듯 당신의 집이 편안하도록, WaveHome</h1>
                <p>레이더 센서로 제스처를 인식하고 IoT 기기 상태를 한 화면에서 관리합니다.</p>
              </div>
              <div className="hero-logo-visual">
                <img src={logoWithStringImage} alt="WaveHome logo with text" />
              </div>
            </div>

            <div className="metric-grid">
              <Metric label="Radar 상태" value="정상" detail="실시간 감지 중" accent="radar" />
              <Metric label="오늘 인식" value={`${gestureHistory.length}회`} detail="로그 데이터 기준" />
              <Metric label="연결된 IoT" value={`${connectedDeviceCount}/${iotDevices.length}`} detail="활성 제어가 있는 온라인 기기" />
              <Metric label="활성 제스처" value={activeGestureSet.name} detail={`${activeGestureSet.gestureNames.length}개 제스처 사용 가능`} />
            </div>
          </section>
        )}

        {activeView === 'history' && (
          <section className="view">
            <PageHeader title="제스처 히스토리" description="그동안 인식된 제스처와 연결된 IoT 동작 기록입니다." />
            <Panel title="인식 로그">
              <HistoryList items={gestureHistory} />
            </Panel>
          </section>
        )}

        {activeView === 'gestures' && (
          <section className="view">
            {selectedGestureSet ? (
              <>
                <div className="gesture-view-toolbar">
                  <button className="back-button" type="button" onClick={() => setSelectedGestureSetId(null)}>
                    ← 뒤로가기
                  </button>
                  <div>
                    <span className="eyebrow">Gesture Set</span>
                    <h1>{selectedGestureSet.name}</h1>
                    <p>{selectedGestureSet.description}</p>
                  </div>
                  <button
                    className={`activate-set-button ${activeGestureSetId === selectedGestureSet.id ? 'active' : ''}`}
                    type="button"
                    onClick={() => activateGestureSet(selectedGestureSet.id)}
                  >
                    {activeGestureSetId === selectedGestureSet.id ? '활성 세트' : '이 세트 활성화'}
                  </button>
                </div>

                {gestureList.length > 0 ? (
                  <div className="gesture-grid">
                    {gestureList.map((gesture) => (
                    <article
                      className="gesture-card"
                      key={gesture.name}
                    >
                      <div>
                        <span className={`status-pill ${gesture.status === '활성' ? 'success' : 'inactive'}`}>
                          {gesture.status}
                        </span>
                        <div className="gesture-media" aria-label={`${gesture.name} media preview`}>
                          <div className="gesture-photo">
                            <img src={gesture.imageSrc} alt={gesture.name} />
                          </div>
                          <div className="gesture-hover-video">
                            {gesture.videoSrc ? (
                              <video autoPlay loop muted playsInline src={gesture.videoSrc}>
                                <track kind="captions" />
                              </video>
                            ) : (
                              <span>VIDEO</span>
                            )}
                          </div>
                        </div>
                        <h3>{gesture.name}</h3>
                      </div>
                    </article>
                    ))}
                  </div>
                ) : (
                  <div className="empty-state">
                    <strong>등록된 제스처가 없습니다.</strong>
                    <span>이미지를 추가하면 이 세트에 제스처가 표시됩니다.</span>
                  </div>
                )}
              </>
            ) : (
              <>
                <PageHeader title="제스처 목록" description="사용할 제스처 묶음을 선택하고, IoT 제어에 적용할 활성 세트를 지정합니다." />
                <div className="gesture-set-grid">
                  {gestureSets.map((set) => (
                    <article className={`gesture-set-card ${activeGestureSetId === set.id ? 'active' : ''}`} key={set.id}>
                      <div>
                        <span className={`status-pill ${activeGestureSetId === set.id ? 'success' : 'inactive'}`}>
                          {activeGestureSetId === set.id ? '활성 세트' : '대기'}
                        </span>
                        <h2>{set.name}</h2>
                        <p>{set.description}</p>
                        <strong>{set.gestureNames.length}개 제스처</strong>
                      </div>
                      <div className="set-actions">
                        <button type="button" onClick={() => setSelectedGestureSetId(set.id)}>
                          목록 보기
                        </button>
                        <button type="button" onClick={() => activateGestureSet(set.id)}>
                          활성화
                        </button>
                      </div>
                    </article>
                  ))}
                </div>
              </>
            )}
          </section>
        )}

        {activeView === 'devices' && (
          <section className="view">
            <PageHeader title="IoT 목록과 상태" description="WaveHome과 연결된 기기의 연결 상태와 현재 전원 상태를 확인합니다." />
            <div className="active-set-banner">
              <span>활성 제스처 세트</span>
              <strong>{activeGestureSet.name}</strong>
            </div>
            <div className="iot-control-layout">
              <Panel title="기기 목록">
                <DeviceList
                  items={iotDevices}
                  selectedId={selectedDevice.id}
                  onSelect={setSelectedDeviceId}
                  getControlState={getDeviceControlState}
                />
              </Panel>

              <Panel title={`${selectedDevice.name} 제어 설정`}>
                <div className="selected-device-summary">
                  <span className={`device-dot ${selectedDeviceControlState}`} />
                  <div>
                    <strong>{selectedDevice.state}</strong>
                    <span>{selectedDevice.room}</span>
                  </div>
                  <button className="deactivate-button" type="button" onClick={deactivateSelectedDevice}>
                    전체 비활성
                  </button>
                </div>

                <div className="control-list">
                  {selectedDevice.controls.map((control) => (
                    <label className="control-row" key={control}>
                      <span>{control}</span>
                      <select
                        value={getEffectiveControlGesture(selectedDevice, control)}
                        onChange={(event) => updateControlGesture(control, event.target.value)}
                      >
                        <option value="">비활성</option>
                        {gestures
                          .filter((gesture) => activeSetGestureNames.includes(gesture.name))
                          .map((gesture) => {
                            const controlKey = `${selectedDevice.id}-${control}`;
                            const isUsedByAnotherControl = Object.entries(controlGestures).some(
                              ([key, value]) => key !== controlKey && value === gesture.name
                            );

                            return (
                            <option key={gesture.name} value={gesture.name} disabled={isUsedByAnotherControl}>
                              {gesture.name}
                              {isUsedByAnotherControl ? ' (사용 중)' : ''}
                            </option>
                            );
                          })}
                      </select>
                    </label>
                  ))}
                </div>
              </Panel>
            </div>
          </section>
        )}
      </main>
    </div>
  );
}

function Metric({ label, value, detail, accent }) {
  return (
    <article className={`metric-card ${accent === 'radar' ? 'radar-metric' : ''}`}>
      <span>{label}</span>
      <strong>{value}</strong>
      <small>{detail}</small>
    </article>
  );
}

function Panel({ title, children }) {
  return (
    <section className="panel">
      <h2>{title}</h2>
      {children}
    </section>
  );
}

function PageHeader({ title, description }) {
  return (
    <header className="page-header">
      <span className="eyebrow">WaveHome Dashboard</span>
      <h1>{title}</h1>
      <p>{description}</p>
    </header>
  );
}

function HistoryList({ items, compact = false }) {
  return (
    <div className={compact ? 'history-list compact' : 'history-list'}>
      {items.map((item) => (
        <article className="history-item" key={item.id}>
          <div className="history-icon">✦</div>
          <div>
            <strong>{item.gesture}</strong>
            <span>
              {item.device} · {item.action}
            </span>
          </div>
          <time>{item.time}</time>
        </article>
      ))}
    </div>
  );
}

function DeviceList({ items, compact = false, selectedId, onSelect, getControlState }) {
  return (
    <div className={compact ? 'device-list compact' : 'device-list'}>
      {items.map((device) => (
        <button
          className={`device-row ${selectedId === device.id ? 'selected' : ''} ${onSelect ? 'selectable' : ''}`}
          key={device.name}
          onClick={() => onSelect?.(device.id)}
          type="button"
        >
          <span className={`device-dot ${getControlState ? getControlState(device) : device.connection}`} />
          <div>
            <strong>{device.name}</strong>
            <span>{device.room}</span>
          </div>
          <span className="device-state">{device.state}</span>
        </button>
      ))}
    </div>
  );
}

export default App;
